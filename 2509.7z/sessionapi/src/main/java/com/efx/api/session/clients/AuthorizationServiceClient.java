package com.efx.api.session.clients;



import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.efx.api.session.pojos.Permission;

@FeignClient("AuthorizationService")
public interface AuthorizationServiceClient {
	
	@GetMapping(path = "/api/auth/getPermission/{id}")
	List<Permission> getPermissionsByUserId (long id);
	@GetMapping(path = "/api/auth/getAllPermission")
	List<Permission> getAllPermissions ();
}
