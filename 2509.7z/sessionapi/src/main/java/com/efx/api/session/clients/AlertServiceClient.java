package com.efx.api.session.clients;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("AlertService")
public interface AlertServiceClient {

	@GetMapping(path = "/type/list", produces = MediaType.APPLICATION_JSON_VALUE)
	Map<Long, String> getAllAlertTypes ();
	
}