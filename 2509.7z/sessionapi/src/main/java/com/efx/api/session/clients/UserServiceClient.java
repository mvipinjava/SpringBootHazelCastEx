package com.efx.api.session.clients;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.efx.api.session.pojos.User;

@FeignClient("UserService")
public interface UserServiceClient
{
//	@GetMapping(path = "/api/user/validate/{name}/{password}")	
	//Optional<User> validateUser (String username, String password);
	@RequestMapping(method = RequestMethod.GET, value = "/api/user/validate/{username}/{password}", consumes = "application/json")    
	Optional<User> validateUser (@PathVariable("username") String username, @PathVariable("password") String password);

	@GetMapping(path = "/terms/{id}")
	Optional<Long> getTermsAgreedToByUserId (long userid);
	@GetMapping(path = "/api/user/name/{name}")
	Optional<Long> getUserIdByUserName (String name);
}

