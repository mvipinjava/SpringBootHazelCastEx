package com.efx.api.session.clients;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.efx.api.session.pojos.PrivacyPolicy;
import com.efx.api.session.pojos.Terms;



@FeignClient("ConfigService")
public interface ConfigServiceClient
{
	@GetMapping(path = "/api/config/currentTerm/{id}")	
	boolean isCurrentTerms (long id);
	@GetMapping(path = "/api/config/currentTerm")	
	Optional<Terms> getCurrentTerms ();
	@GetMapping(path = "/api/config/currentPolicy")
	Optional<PrivacyPolicy> getCurrentPrivacyPolicy ();
	
}

