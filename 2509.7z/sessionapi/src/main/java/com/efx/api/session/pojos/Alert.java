package com.efx.api.session.pojos;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Alert implements Serializable
{
	private static final long serialVersionUID = 1L;

	long terminal_id;
	String terminal_name;
	String terminal_type;
	String alert_message;
}
