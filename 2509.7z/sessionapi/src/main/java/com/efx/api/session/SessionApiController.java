package com.efx.api.session;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.RestTemplate;

import com.efx.api.session.clients.AlertServiceClient;
import com.efx.api.session.clients.AuthorizationServiceClient;
import com.efx.api.session.clients.ConfigServiceClient;
import com.efx.api.session.clients.GoalServiceClient;
import com.efx.api.session.clients.ImageServiceClient;
import com.efx.api.session.clients.UserServiceClient;
import com.efx.api.session.pojos.AlarmData;
import com.efx.api.session.pojos.AllUserResponse;
import com.efx.api.session.pojos.GoalData;
import com.efx.api.session.pojos.LoginRequest;
import com.efx.api.session.pojos.LoginResponse;
import com.efx.api.session.pojos.Permission;
import com.efx.api.session.pojos.PermissionData;
import com.efx.api.session.pojos.PhotoData;
import com.efx.api.session.pojos.PrivacyData;
import com.efx.api.session.pojos.PrivacyPolicy;
import com.efx.api.session.pojos.Terms;
import com.efx.api.session.pojos.TermsData;
import com.efx.api.session.pojos.User;
import com.efx.api.session.pojos.UserData;
import com.efx.api.session.pojos.UserPermissionData;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/session")
@Api(description = "REST APIs related to User Session API")

public class SessionApiController {
	public static final String USERNAME_HEADER = "API_USERNAME";
	Logger logger = null;

    @Autowired
    RestTemplate restTemplate;
    
    @Autowired
    HazelcastInstance hazelcastInstance;

	
    @Autowired
    private ConfigServiceClient configServiceClient;
    
    @Autowired
    private UserServiceClient userServiceClient;
    
    private AuthorizationServiceClient authorizationServiceClient;
    
    @Autowired
    private AlertServiceClient alertServiceClient;
    
    @Autowired
    private GoalServiceClient goalServiceClient;
    
    @Autowired
    private ImageServiceClient imageServiceClient;
    
    
    
    @PostMapping("/login")
    //@Cacheable(value="jwt",key="#token")
    @ApiOperation(value = "User login - Post username and password")
    @ApiResponses(value = {
    	@ApiResponse(code = 200, message = "Success|OK"),
        @ApiResponse(code = 400, message = "Something went wrong"),         
        @ApiResponse(code = 404, message = "not found!!!"),
        @ApiResponse(code = 422, message = "Invalid username/password supplied")})
    public LoginResponse login( @RequestBody @NotNull LoginRequest request) {
    	LoginResponse rs=new LoginResponse();
    	/* validate user by username and password using userServiceClient - Feign Client start
    	 * if user validate true then set all other pojos like TermsData, PrivacyData..etc
    	 *  */
    	Optional<User> userOb=userServiceClient.validateUser(request.getUsername(), request.getPassword());
    	if(userOb.isPresent()) {
    		User usrOb=userOb.get();    		
    		Long userId=usrOb.getId();
    		
    		/* set TermsData pojos start */
    		Optional<Long> terms=userServiceClient.getTermsAgreedToByUserId(userId);
    		boolean isTerm=false;
    		boolean requireTerms=true;
    		if(terms.isPresent()) {
    			isTerm=true;
    		}
    		boolean cTerm = configServiceClient.isCurrentTerms(userId);
    		if((isTerm==true) && (cTerm==true)) {
    			requireTerms=false;
    		}
    		TermsData termsData=new TermsData();
    		termsData.setRequiresTerms(requireTerms);
    		Optional<Terms> currentTerms=configServiceClient.getCurrentTerms();
    		if(currentTerms.isPresent()) {
    			Terms currentTermOb=currentTerms.get();
    			termsData.setCurrentVersion(currentTermOb.getVersion());
    			termsData.setVerbage(currentTermOb.getVerbage());
    		}
    		/* set TermsData pojos end */
    		
    		/* set PrivacyData pojos start */
    		Optional<PrivacyPolicy> privacyPolicy= configServiceClient.getCurrentPrivacyPolicy ();
    		PrivacyData privacyData = new PrivacyData();
    		if(privacyPolicy.isPresent()) {
    			PrivacyPolicy privacyPolicyOb=privacyPolicy.get();
    			privacyData.setCurrentVersion(privacyPolicyOb.getVersion());
    			privacyData.setVerbage(privacyPolicyOb.getVerbage());
    			
    		}
    		/* set PrivacyData pojos end */
    		
    		/* set authorizationService Permission start */
    		List<Permission> userPermission=authorizationServiceClient.getPermissionsByUserId(userId);
    		
    		List<UserPermissionData> userPermissionData=new ArrayList<>();
    		for(Permission permission:userPermission) {
    			UserPermissionData userPermissiodt=new UserPermissionData();
    			userPermissiodt.setId(permission.getId());    			
    			userPermissionData.add(userPermissiodt);
    		}
    		
    		List<Permission> allPermission=authorizationServiceClient.getAllPermissions ();
    		
    		List<PermissionData> allPermissionData=new ArrayList<>();
    		for(Permission permission:allPermission) {
    			PermissionData permissiodt=new PermissionData();
    			permissiodt.setId(permission.getId());
    			permissiodt.setName(permission.getName());
    			allPermissionData.add(permissiodt);
    		} 		
    		/* set authorizationService Permission end */
    		
    		/* set AlertType start */
    		Map<Long,String> alerts=alertServiceClient.getAllAlertTypes();
    		List<AlarmData> alertTypes=new ArrayList<>();
    		
    		alerts.entrySet().stream().forEachOrdered((x)->{
    			AlarmData alData=new AlarmData();
    			alData.setId(x.getKey());
    			alData.setName(x.getValue());
    			alertTypes.add(alData);
    			});    		
    		
    		/* set AlertType start */
    		
    		/* set GoalType start */
    		Map<Long,String> goals=goalServiceClient.getAllGoalTypes();
    		List<GoalData> goalTypes=new ArrayList<>();
    		goals.entrySet().stream().forEachOrdered((x)->{
    			GoalData glData=new GoalData();
    			glData.setId(x.getKey());
    			glData.setName(x.getValue());
    			goalTypes.add(glData);
    			});
    		
    		/* set GoalType end */
    		/* set PhotoType start */
    		Map<Long,String> photos=imageServiceClient.getAllImageTypes();
    		List<PhotoData> photoTypes=new ArrayList<>();
    		photos.entrySet().stream().forEachOrdered((x)->{
    			PhotoData phData=new PhotoData();
    			phData.setId(x.getKey());
    			phData.setName(x.getValue());
    			photoTypes.add(phData);
    			});
    		/* set PhotoType end */
    		
    		
    		
    		/* generate Token */
    		String token=RandomStringUtils.randomAlphanumeric(32, 64);
    		
    		/* set Token in LoginRespose */    		
    		rs.setToken(token);
    		/* set TermsData in LoginRespose */
    		rs.setTerms(termsData);
    		/* set PrivacyData in LoginRespose */
    		rs.setPrivacy(privacyData);
    		/* set UserPermissionData in LoginRespose */
    		rs.setUserPermissions(userPermissionData);
    		/* set AllPermissionData in LoginRespose */
    		rs.setPermissions(allPermissionData);
    		/* set AlertTypes in LoginRespose */
    		rs.setAlertTypes(alertTypes);
    		/* set GoalTypes in LoginRespose */
    		rs.setGoalTypes(goalTypes);
    		
    		IMap<String, String> queue;
    		queue = hazelcastInstance.getMap("jwt");    		 
    		 queue.put(request.getUsername(), token);
    	}
    	
    	
    	return rs;
    }
    
    
    @GetMapping("/logout")    
    @ApiOperation("User Logout")
    @ApiResponses(value = {	@ApiResponse(code = 204, message = "Success|OK")})
    public void logout(@RequestHeader(USERNAME_HEADER) String username) {  
    	IMap<String, String> queue;
		queue = hazelcastInstance.getMap("jwt");  
		queue.remove(username);   	
		
    }
    
    
    @GetMapping("/list")    
    @ApiOperation("Get All Loggedin Users List")
    @ApiResponses(value = {	@ApiResponse(code = 204, message = "Success|OK")})
    public ResponseEntity<?> getAllUserLoggedin() {  
    	IMap<String, String> queue;
		queue = hazelcastInstance.getMap("jwt");  		
		
		ResponseEntity<?> rs =null;		
		if(!queue.isEmpty()) {
			List<UserData> usersData=new ArrayList<>();
			queue.entrySet().stream().forEachOrdered((x)->{
					UserData usrData = new UserData();
					Optional<Long> userId=userServiceClient.getUserIdByUserName(x.getKey());
					if(userId.isPresent()) {
						Long usrId=userId.get();
						usrData.setId(usrId);
						usrData.setUsername(x.getKey());
					}
				});
			if(!usersData.isEmpty()) {
				AllUserResponse allUserResponse=new AllUserResponse();
				allUserResponse.setUsers(usersData);
				rs = new ResponseEntity<AllUserResponse>(allUserResponse,HttpStatus.OK);
			}else {
				rs=new ResponseEntity<String>("No Active User Found",HttpStatus.NO_CONTENT);
			}	
		}
		else {
			rs=new ResponseEntity<String>("No Active User Found",HttpStatus.NO_CONTENT);
		}
		return rs;
		
    }
   
    
}
