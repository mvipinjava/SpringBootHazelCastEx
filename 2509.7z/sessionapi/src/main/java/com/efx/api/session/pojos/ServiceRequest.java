package com.efx.api.session.pojos;

import java.io.Serializable;


public class ServiceRequest implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	long id;
	String name;
	long value;
	long userid;
	long terminal_id;
	public ServiceRequest(long id, String name, long value, long userid, long terminal_id) {
		super();
		this.id = id;
		this.name = name;
		this.value = value;
		this.userid = userid;
		this.terminal_id = terminal_id;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getValue() {
		return value;
	}
	public void setValue(long value) {
		this.value = value;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public long getTerminal_id() {
		return terminal_id;
	}
	public void setTerminal_id(long terminal_id) {
		this.terminal_id = terminal_id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
