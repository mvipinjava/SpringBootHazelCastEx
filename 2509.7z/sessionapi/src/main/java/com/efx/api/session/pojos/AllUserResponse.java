package com.efx.api.session.pojos;

import java.util.List;

import lombok.*;

@Setter
@Getter
public class AllUserResponse
{	
	List<UserData> users;	
}
