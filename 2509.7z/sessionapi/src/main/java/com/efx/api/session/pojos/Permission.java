package com.efx.api.session.pojos;

import com.efx.common.base.ExportableObject;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Permission implements ExportableObject
{
	Long id;
	String name;
	String description;
}
