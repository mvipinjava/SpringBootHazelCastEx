package com.efx.api.session.pojos;

import java.io.Serializable;

import lombok.*;

@Setter
@Getter
public class LoginRequest implements Serializable
{
	private static final long serialVersionUID = 1L;

	String username;
	String password;
}
