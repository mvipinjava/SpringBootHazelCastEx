package com.efx.api.session.pojos;

import java.util.Date;
import java.util.List;

import com.efx.common.base.ExportableObject;

import lombok.*;

@Setter
@Getter
public class User implements ExportableObject
{
	Long id;
	Long parent_userId;
	List<Long> childUserIds;
	Long locationId;
	Long organizationId;
	String username;
	String email;
	String first_name;
	String middle_name;
	String last_name;
	String cellPhoneNumber;
	String password;
	UserStatus status;
	Long termsAgreedTo;
	Date termsAgreedToDate;
	
	Boolean pushRegistered;
	
	Boolean admin;
	Long avatarId;		// an Image object
	
	Integer invalidLoginAttempts;
	Date lastSucessfulLogon;
}
