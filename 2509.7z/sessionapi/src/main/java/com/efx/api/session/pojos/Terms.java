package com.efx.api.session.pojos;

import com.efx.common.base.ExportableObject;

import lombok.*;

@Setter
@Getter
public class Terms implements ExportableObject
{
	Long id;
	Long version;
	Boolean currentVersion;
	String verbage;
}
