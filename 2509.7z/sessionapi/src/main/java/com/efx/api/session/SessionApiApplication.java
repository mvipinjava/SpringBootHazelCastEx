package com.efx.api.session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

import com.efx.common.utils.SwaggerUtils;
import com.netflix.discovery.EurekaClient;

import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@EnableCaching
@ComponentScan(basePackages = "com.efx")
@EnableFeignClients
public class SessionApiApplication {

	// this variable is just used for unit testing
	static ConfigurableApplicationContext context = null;
	
	@Autowired
	EurekaClient eurekaClient;
	
	public static void main(String[] args) {
		context = SpringApplication.run(SessionApiApplication.class, args);
	}

	@LoadBalanced
	@Bean
	RestTemplate restTemplate() {
		return new RestTemplate();
	}
		 
	 @Bean
		public Docket api() {
			return SwaggerUtils.getInstance().getSwaggerDocket("Session Api", "This api for user session management");
		}
	 
	 
	 
	 
}
