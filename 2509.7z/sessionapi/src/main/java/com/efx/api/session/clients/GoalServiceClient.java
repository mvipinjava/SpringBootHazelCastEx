package com.efx.api.session.clients;

import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("GoalService")
public interface GoalServiceClient
{
	@GetMapping(path = "/goaltype/list", produces = MediaType.APPLICATION_JSON_VALUE)
    Map<Long, String> getAllGoalTypes();
    
}
