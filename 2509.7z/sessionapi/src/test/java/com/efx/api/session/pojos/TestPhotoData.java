package com.efx.api.session.pojos;

import java.beans.IntrospectionException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.efx.POJOTester.POJOTester;

@DisplayName("PhotoData")
class TestPhotoData
{
	@Test
	public void testBeanProperties() throws IntrospectionException
	{
	    POJOTester.test(PhotoData.class);
	}
}
