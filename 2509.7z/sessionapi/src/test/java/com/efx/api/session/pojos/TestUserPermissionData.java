package com.efx.api.session.pojos;

import java.beans.IntrospectionException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.efx.POJOTester.POJOTester;

@DisplayName("UserPermissionData")
class TestUserPermissionData
{
	@Test
	public void testBeanProperties() throws IntrospectionException
	{
	    POJOTester.test(UserPermissionData.class);
	}
}
